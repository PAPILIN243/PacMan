package edu.upb.lp.game.internal;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineEvent;

import javax.swing.AbstractAction;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRootPane;
import javax.swing.KeyStroke;
import javax.swing.SwingConstants;
import javax.swing.Timer;

import edu.upb.lp.game.core.GameController;
import edu.upb.lp.game.core.GameUI;

public class SwingUI extends JFrame implements GameUI {

	private static final long serialVersionUID = 156933677961172524L;

	private CellPanel[][] cells;

	private Color cellTextColor = Color.WHITE;

	private JPanel gridPanel;
	private JPanel buttonPanel;
	private JPanel infoPanel;

	private JLabel temporaryMessageLabel;

	private GameController controller;

	private final Map<String, JButton> buttons = new HashMap<>();
	private final Map<String, JLabel> labels = new HashMap<>();
	private final Map<String, ImageIcon> imageCache = new HashMap<>();
	private final Map<String, Timer> loops = new HashMap<>();
	private final List<Clip> activeClips = new ArrayList<>();

	private static final int CELL_SIZE = 80;

	public SwingUI() {
		setTitle("UPBGame Swing Edition 2026");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLayout(new BorderLayout());

		infoPanel = new JPanel();
		buttonPanel = new JPanel();
		gridPanel = new JPanel();

		infoPanel.setLayout(new GridLayout(2, 4));
		buttonPanel.setLayout(new FlowLayout());
		gridPanel.setLayout(new GridLayout(8, 8, 0, 0));

		add(infoPanel, BorderLayout.NORTH);
		add(gridPanel, BorderLayout.CENTER);

		temporaryMessageLabel = new JLabel(" ");
		temporaryMessageLabel.setHorizontalAlignment(SwingConstants.CENTER);
		temporaryMessageLabel.setFont(new Font("Arial", Font.BOLD, 14));

		JPanel southPanel = new JPanel(new BorderLayout());
		southPanel.add(temporaryMessageLabel, BorderLayout.NORTH);
		southPanel.add(buttonPanel, BorderLayout.SOUTH);

		add(southPanel, BorderLayout.SOUTH);

		setLocationRelativeTo(null);
		setVisible(true);
	}

	public void setController(GameController controller) {
		this.controller = controller;
	}

	@Override
	public void configureGrid(int rows, int cols, int sizeX, int sizeY, boolean showCellBorders) {
		setSize(sizeX, sizeY);
		setLocationRelativeTo(null);

		gridPanel.removeAll();
		gridPanel.setLayout(new GridLayout(rows, cols, 0, 0));

		cells = new CellPanel[rows][cols];

		for (int row = 0; row < rows; row++) {
			for (int col = 0; col < cols; col++) {
				CellPanel cellPanel = new CellPanel();
				cellPanel.setShowBorder(showCellBorders);
				cellPanel.setTextColor(cellTextColor);
				int currentRow = row;
				int currentCol = col;

				cellPanel.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent e) {
						if (controller != null) {
							controller.onCellPressed(currentRow, currentCol);
						}
					}
				});

				cells[row][col] = cellPanel;
				gridPanel.add(cellPanel);
			}
		}

		revalidate();
		repaint();
	}

	@Override
	public void setCellText(int row, int col, String text) {
		if (isValidCell(row, col)) {
			cells[row][col].setCellText(text);
		}
	}

	@Override
	public void setCellTextColor(String colorName) {
		cellTextColor = getColorByName(colorName);

		if (cells != null) {
			for (int row = 0; row < cells.length; row++) {
				for (int col = 0; col < cells[row].length; col++) {
					cells[row][col].setTextColor(cellTextColor);
				}
			}
		}

		repaint();
	}

	private Color getColorByName(String colorName) {
		if (colorName == null) {
			return Color.WHITE;
		}

		switch (colorName.toLowerCase()) {
		case "black":
			return Color.BLACK;
		case "white":
			return Color.WHITE;
		case "red":
			return Color.RED;
		case "green":
			return Color.GREEN;
		case "blue":
			return Color.BLUE;
		case "yellow":
			return Color.YELLOW;
		case "orange":
			return Color.ORANGE;
		case "pink":
			return Color.PINK;
		case "gray":
		case "grey":
			return Color.GRAY;
		case "cyan":
			return Color.CYAN;
		case "magenta":
			return Color.MAGENTA;
		default:
			return Color.WHITE;
		}
	}

	@Override
	public void setCellBackgroundImage(int row, int col, String imageName) {
		if (isValidCell(row, col)) {
			cells[row][col].setBackgroundIcon(loadImage(imageName));
		}
	}

	@Override
	public void setCellObjectImage(int row, int col, String imageName) {
		if (isValidCell(row, col)) {
			cells[row][col].setObjectIcon(loadImage(imageName));
		}
	}

	@Override
	public void clearCellObjectImage(int row, int col) {
		if (isValidCell(row, col)) {
			cells[row][col].clearObjectIcon();
		}
	}

	@Override
	public void addButton(String name) {
		if (!buttons.containsKey(name)) {
			JButton button = new JButton(name);

			button.addActionListener(e -> {
				if (controller != null) {
					controller.onButtonPressed(name);
				}
			});

			buttons.put(name, button);
			buttonPanel.add(button);

			revalidate();
			repaint();
		}
	}

	@Override
	public void removeButton(String name) {
		JButton button = buttons.remove(name);

		if (button != null) {
			buttonPanel.remove(button);
			revalidate();
			repaint();
		}
	}

	@Override
	public void setLabel(String key, String value) {
		if (!labels.containsKey(key)) {
			JLabel label = new JLabel(value);
			label.setHorizontalAlignment(SwingConstants.CENTER);
			labels.put(key, label);
			infoPanel.add(label);
		} else {
			labels.get(key).setText(value);
		}

		revalidate();
		repaint();
	}

	@Override
	public void showMessage(String msg) {
		JOptionPane.showMessageDialog(this, msg);
	}

	@Override
	public String askText(String title) {
		return JOptionPane.showInputDialog(this, title);
	}

	private ImageIcon loadImage(String imageName) {
		if (imageName == null || imageName.isBlank()) {
			return null;
		}

		if (imageCache.containsKey(imageName)) {
			return imageCache.get(imageName);
		}

		String[] extensions = { ".png", ".jpg", ".jpeg" };

		for (String ext : extensions) {
			String path = "/images/" + imageName + ext;

			java.net.URL resource = getClass().getResource(path);

			if (resource != null) {
				ImageIcon original = new ImageIcon(resource);

				Image scaled = original.getImage().getScaledInstance(CELL_SIZE, CELL_SIZE, Image.SCALE_SMOOTH);

				ImageIcon icon = new ImageIcon(scaled);
				imageCache.put(imageName, icon);

				return icon;
			}
		}

		System.out.println("Image not found in resources: " + imageName);
		return null;
	}

	private boolean isValidCell(int row, int col) {
		return cells != null && row >= 0 && row < cells.length && col >= 0 && col < cells[row].length;
	}

	@Override
	public void showTemporaryMessage(String msg) {
		temporaryMessageLabel.setText(msg);

		Timer timer = new Timer(2500, e -> temporaryMessageLabel.setText(" "));
		timer.setRepeats(false);
		timer.start();
	}

	@Override
	public void executeLater(Runnable runnable, int milliseconds) {
		Timer timer = new Timer(milliseconds, e -> runnable.run());
		timer.setRepeats(false);
		timer.start();
	}

	@Override
	public String executeRepeatedly(Runnable runnable, int milliseconds) {
		String loopId = UUID.randomUUID().toString();

		Timer timer = new Timer(milliseconds, e -> runnable.run());
		timer.start();

		loops.put(loopId, timer);

		return loopId;
	}

	@Override
	public void stopLoop(String loopId) {
		Timer timer = loops.remove(loopId);

		if (timer != null) {
			timer.stop();
		}
	}

	@Override
	public void playSound(String soundName) {
		if (soundName == null || soundName.isBlank()) {
			return;
		}

		try {
			URL soundUrl = getClass().getResource("/sounds/" + soundName + ".wav");

			if (soundUrl == null) {
				System.out.println("Sound not found: " + soundName);
				return;
			}

			AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(soundUrl);
			Clip clip = AudioSystem.getClip();

			clip.open(audioInputStream);
			clip.start();

			activeClips.add(clip);

			clip.addLineListener(event -> {
				if (event.getType() == LineEvent.Type.STOP) {
					clip.close();
					activeClips.remove(clip);
				}
			});

		} catch (Exception e) {
			System.out.println("Error playing sound: " + soundName);
			e.printStackTrace();
		}
	}

	@Override
	public void stopSounds() {
		for (Clip clip : new ArrayList<>(activeClips)) {
			if (clip.isRunning()) {
				clip.stop();
			}
			clip.close();
		}

		activeClips.clear();
	}

	@Override
	public void bindKey(String key, String command) {
		String normalizedKey = key.toUpperCase();

		KeyStroke keyStroke = KeyStroke.getKeyStroke(normalizedKey);

		if (keyStroke == null) {
			System.out.println("Invalid key: " + key);
		} else {

			JRootPane rootPane = getRootPane();

			rootPane.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(keyStroke, command);

			rootPane.getActionMap().put(command, new AbstractAction() {
				private static final long serialVersionUID = 52766690820023871L;

				@Override
				public void actionPerformed(java.awt.event.ActionEvent e) {
					if (controller != null) {
						controller.onCommand(command);
					}
				}
			});
		}
	}
}